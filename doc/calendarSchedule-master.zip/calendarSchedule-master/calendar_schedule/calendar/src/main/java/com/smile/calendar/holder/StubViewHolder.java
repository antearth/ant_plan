package com.smile.calendar.holder;

/**
 * Created by Blaz Solar on 22/04/14.
 */
public class StubViewHolder extends AbstractViewHolder {

    @Override
    protected void onAnimate(float time) {
        // do nothing
    }

    @Override
    public void onFinish(boolean done) {
        // do nothing
    }

}
