# RVCalendar
基于RecyclerView自定义日历包含农历，可单选，可范围选
![单选效果](https://github.com/Mitaxing/RVCalendar/blob/master/images/Screenshot_1525420734.png)

![范围选择效果](https://github.com/Mitaxing/RVCalendar/blob/master/images/Screenshot_1525418573.png)
